import { Component, OnDestroy, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { IqService, IqAnswer, IQ_QUESTIONS, IqQuestion } from '../../core/services/iq.service';

type QuizState = 'intro' | 'quiz' | 'submitting' | 'done';

@Component({
  selector: 'app-iq',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './iq.html'
})
export class IqComponent implements OnDestroy {

  state = signal<QuizState>('intro');
  currentIndex = signal(0);
  selectedOption = signal<number | null>(null);
  answers = signal<IqAnswer[]>([]);

  private questionStartTime = 0;
  private quizStartTime = 0;

  questions = IQ_QUESTIONS;

  currentQuestion = computed<IqQuestion>(() => this.questions[this.currentIndex()]);

  progress = computed(() =>
    Math.round((this.currentIndex() / this.questions.length) * 100)
  );

  categoryLabel = computed(() => ({
    visual:  'Matrices Visuales',
    series:  'Series',
    verbal:  'Razonamiento Verbal'
  }[this.currentQuestion().category]));

  difficultyLabel = computed(() => ({
    easy:   'Fácil',
    medium: 'Medio',
    hard:   'Difícil'
  }[this.currentQuestion().difficulty]));

  constructor(private iqService: IqService, private router: Router) {}

  ngOnDestroy(): void {}

  startQuiz(): void {
    this.quizStartTime = Date.now();
    this.questionStartTime = Date.now();
    this.state.set('quiz');
  }

  selectOption(index: number): void {
    if (this.selectedOption() !== null) return;
    this.selectedOption.set(index);
  }

  next(): void {
    const selected = this.selectedOption();
    if (selected === null) return;

    const q = this.currentQuestion();
    this.answers.update(prev => [...prev, {
      questionId: q.id,
      selectedIndex: selected,
      isCorrect: selected === q.correctIndex,
      timeSpentMs: Date.now() - this.questionStartTime
    }]);

    this.selectedOption.set(null);
    this.questionStartTime = Date.now();

    const next = this.currentIndex() + 1;
    if (next >= this.questions.length) {
      this.submit();
    } else {
      this.currentIndex.set(next);
    }
  }

  private submit(): void {
    this.state.set('submitting');
    this.iqService.submitResults({
      answers: this.answers(),
      totalTimeMs: Date.now() - this.quizStartTime,
      completedAt: new Date().toISOString()
    }).subscribe({
      next: () => this.state.set('done'),
      error: () => this.state.set('done')
    });
  }

  getOptionClass(index: number): string {
    const selected = this.selectedOption();
    if (selected === null) return '';
    const correct = this.currentQuestion().correctIndex;
    if (index === correct) return 'correct';
    if (index === selected && selected !== correct) return 'incorrect';
    return 'dimmed';
  }

  isOptionDisabled(): boolean {
    return this.selectedOption() !== null;
  }
}